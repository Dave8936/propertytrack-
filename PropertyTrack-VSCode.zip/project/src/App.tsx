import { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CurrencyProvider } from './context/CurrencyContext';
import AuthPage from './pages/AuthPage';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Properties from './pages/Properties';
import Tenants from './pages/Tenants';
import Transactions from './pages/Transactions';

type Page = 'dashboard' | 'properties' | 'tenants' | 'transactions';

function AppInner() {
  const { user, loading } = useAuth();
  const [page, setPage] = useState<Page>('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) return <AuthPage />;

  const pageMap: Record<Page, JSX.Element> = {
    dashboard: <Dashboard />,
    properties: <Properties />,
    tenants: <Tenants />,
    transactions: <Transactions />,
  };

  return (
    <Layout page={page} onNavigate={setPage}>
      {pageMap[page]}
    </Layout>
  );
}

export default function App() {
  return (
    <CurrencyProvider>
      <AuthProvider>
        <AppInner />
      </AuthProvider>
    </CurrencyProvider>
  );
}
