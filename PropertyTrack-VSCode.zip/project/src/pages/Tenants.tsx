import { useEffect, useState } from 'react';
import { Plus, Users, Pencil, Trash2, CheckCircle, XCircle, Phone, Mail } from 'lucide-react';
import { supabase, Tenant, Property } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import Modal from '../components/Modal';

function fmt(n: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

const emptyTenant = (): Partial<Tenant> => ({
  name: '', email: '', phone: '', monthly_rent: 0,
  lease_start: '', lease_end: '', status: 'active', notes: '', property_id: '',
});

export default function Tenants() {
  const { user } = useAuth();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<'add' | 'edit' | null>(null);
  const [form, setForm] = useState<Partial<Tenant>>(emptyTenant());
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'inactive'>('all');

  async function load() {
    if (!user) return;
    const [t, p] = await Promise.all([
      supabase.from('tenants').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('properties').select('*').eq('user_id', user.id),
    ]);
    setTenants(t.data ?? []);
    setProperties(p.data ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, [user]);

  function openAdd() {
    setForm({ ...emptyTenant(), property_id: properties[0]?.id ?? '' });
    setError('');
    setModal('add');
  }

  function openEdit(t: Tenant) {
    setForm({ ...t });
    setError('');
    setModal('edit');
  }

  async function save() {
    if (!user) return;
    setSaving(true);
    setError('');
    const payload = {
      user_id: user.id,
      property_id: form.property_id,
      name: form.name,
      email: form.email ?? '',
      phone: form.phone ?? '',
      monthly_rent: Number(form.monthly_rent),
      lease_start: form.lease_start || null,
      lease_end: form.lease_end || null,
      status: form.status ?? 'active',
      notes: form.notes ?? '',
    };
    let err;
    if (modal === 'add') {
      ({ error: err } = await supabase.from('tenants').insert(payload));
    } else {
      ({ error: err } = await supabase.from('tenants').update(payload).eq('id', (form as Tenant).id));
    }
    if (err) { setError(err.message); } else { setModal(null); await load(); }
    setSaving(false);
  }

  async function remove(id: string) {
    if (!confirm('Remove this tenant?')) return;
    await supabase.from('tenants').delete().eq('id', id);
    await load();
  }

  const visible = tenants.filter((t) =>
    filter === 'all' ? true : filter === 'active' ? t.status === 'active' : t.status !== 'active'
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Tenants</h1>
          <p className="text-slate-400 text-sm mt-1">{tenants.filter((t) => t.status === 'active').length} active tenants</p>
        </div>
        <button
          onClick={openAdd}
          disabled={properties.length === 0}
          title={properties.length === 0 ? 'Add a property first' : ''}
          className="flex items-center gap-2 bg-sky-500 hover:bg-sky-400 disabled:opacity-40 text-white text-sm font-semibold px-4 py-2.5 rounded-xl transition"
        >
          <Plus className="w-4 h-4" /> Add Tenant
        </button>
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        {(['all', 'active', 'inactive'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              filter === f ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center">
          <Users className="w-10 h-10 text-slate-700 mx-auto mb-3" />
          <p className="text-slate-400 font-medium">No tenants found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {visible.map((t) => {
            const prop = properties.find((p) => p.id === t.property_id);
            const active = t.status === 'active';
            return (
              <div key={t.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col gap-3 hover:border-slate-700 transition">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-white truncate">{t.name}</p>
                    <p className="text-slate-500 text-xs truncate">{prop?.name ?? 'Unknown property'}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${
                      active ? 'bg-emerald-500/15 text-emerald-400' : 'bg-slate-700 text-slate-500'
                    }`}>
                      {active ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                      {t.status}
                    </span>
                    <button onClick={() => openEdit(t)} className="p-1.5 rounded-lg text-slate-500 hover:text-sky-400 hover:bg-sky-400/10 transition">
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => remove(t.id)} className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-400/10 transition">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="bg-slate-800/50 rounded-xl px-4 py-3 text-center">
                  <p className="text-xs text-slate-500">Monthly Rent</p>
                  <p className="text-xl font-bold text-white mt-0.5">{fmt(t.monthly_rent)}</p>
                </div>

                <div className="space-y-1">
                  {t.email && (
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <Mail className="w-3.5 h-3.5 text-slate-600" /> {t.email}
                    </div>
                  )}
                  {t.phone && (
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <Phone className="w-3.5 h-3.5 text-slate-600" /> {t.phone}
                    </div>
                  )}
                  {t.lease_start && t.lease_end && (
                    <p className="text-xs text-slate-500 mt-1">Lease: {t.lease_start} to {t.lease_end}</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modal && (
        <Modal title={modal === 'add' ? 'Add Tenant' : 'Edit Tenant'} onClose={() => setModal(null)}>
          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-0.5">Property</label>
                <select
                  value={form.property_id ?? ''}
                  onChange={(e) => setForm((f) => ({ ...f, property_id: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-2 text-white text-xs focus:outline-none focus:border-sky-500 transition"
                >
                  {properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-0.5">Status</label>
                <select
                  value={form.status ?? 'active'}
                  onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-2 text-white text-xs focus:outline-none focus:border-sky-500 transition"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="pending">Pending</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-0.5">Name</label>
                <input
                  type="text"
                  value={(form.name as string) ?? ''}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-2 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-sky-500 transition"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-0.5">Monthly Rent</label>
                <input
                  type="number"
                  value={form.monthly_rent ?? 0}
                  onChange={(e) => setForm((f) => ({ ...f, monthly_rent: Number(e.target.value) }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-2 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-sky-500 transition"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-0.5">Email</label>
                <input
                  type="email"
                  value={(form.email as string) ?? ''}
                  onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-2 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-sky-500 transition"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-0.5">Phone</label>
                <input
                  type="text"
                  value={(form.phone as string) ?? ''}
                  onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-2 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-sky-500 transition"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-0.5">Lease Start</label>
                <input
                  type="date"
                  value={(form.lease_start as string) ?? ''}
                  onChange={(e) => setForm((f) => ({ ...f, lease_start: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-2 text-white text-xs focus:outline-none focus:border-sky-500 transition"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-0.5">Lease End</label>
                <input
                  type="date"
                  value={(form.lease_end as string) ?? ''}
                  onChange={(e) => setForm((f) => ({ ...f, lease_end: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-2 text-white text-xs focus:outline-none focus:border-sky-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-0.5">Notes</label>
              <textarea
                value={form.notes ?? ''}
                onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                rows={1}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-2 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-sky-500 transition resize-none"
              />
            </div>

            {error && <p className="text-red-400 text-xs mt-1">{error}</p>}
            <div className="flex gap-2 pt-1">
              <button onClick={() => setModal(null)} className="flex-1 py-2 rounded-lg border border-slate-700 text-slate-300 text-xs hover:bg-slate-800 transition">Cancel</button>
              <button onClick={save} disabled={saving} className="flex-1 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-white text-xs font-semibold transition disabled:opacity-50">
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
