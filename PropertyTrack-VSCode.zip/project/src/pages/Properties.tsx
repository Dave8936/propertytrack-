import { useEffect, useState } from 'react';
import { Plus, Home, Pencil, Trash2, TrendingUp, TrendingDown } from 'lucide-react';
import { supabase, Property } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import Modal from '../components/Modal';

function fmt(n: number, currency: string) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n);
}

const TYPES = ['residential', 'commercial', 'vacation', 'industrial', 'land'];

const empty = (): Partial<Property> => ({
  name: '',
  address: '',
  property_type: 'residential',
  purchase_price: 0,
  current_value: 0,
  purchase_date: '',
  notes: '',
});

export default function Properties() {
  const { user } = useAuth();
  const { currency } = useCurrency();
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<'add' | 'edit' | null>(null);
  const [form, setForm] = useState<Partial<Property>>(empty());
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  async function load() {
    if (!user) return;
    const { data } = await supabase.from('properties').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    setProperties(data ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, [user]);

  function openAdd() {
    setForm(empty());
    setError('');
    setModal('add');
  }

  function openEdit(p: Property) {
    setForm({ ...p });
    setError('');
    setModal('edit');
  }

  async function save() {
    if (!user) return;
    setSaving(true);
    setError('');
    const payload = {
      user_id: user.id,
      name: form.name,
      address: form.address,
      property_type: form.property_type,
      purchase_price: Number(form.purchase_price),
      current_value: Number(form.current_value),
      purchase_date: form.purchase_date || null,
      notes: form.notes ?? '',
    };
    let err;
    if (modal === 'add') {
      ({ error: err } = await supabase.from('properties').insert(payload));
    } else {
      ({ error: err } = await supabase.from('properties').update(payload).eq('id', (form as Property).id));
    }
    if (err) { setError(err.message); } else { setModal(null); await load(); }
    setSaving(false);
  }

  async function remove(id: string) {
    if (!confirm('Delete this property and all its data?')) return;
    await supabase.from('properties').delete().eq('id', id);
    await load();
  }

  function field(k: keyof Property, label: string, type = 'text', opts?: string[]) {
    return (
      <div>
        <label className="block text-xs font-medium text-slate-400 mb-1.5">{label}</label>
        {opts ? (
          <select
            value={(form[k] as string) ?? ''}
            onChange={(e) => setForm((f) => ({ ...f, [k]: e.target.value }))}
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-sky-500 transition"
          >
            {opts.map((o) => <option key={o} value={o}>{o.charAt(0).toUpperCase() + o.slice(1)}</option>)}
          </select>
        ) : (
          <input
            type={type}
            value={(form[k] as string | number) ?? ''}
            onChange={(e) => setForm((f) => ({ ...f, [k]: e.target.value }))}
            className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-sky-500 transition"
          />
        )}
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Properties</h1>
          <p className="text-slate-400 text-sm mt-1">{properties.length} propert{properties.length !== 1 ? 'ies' : 'y'} in portfolio</p>
        </div>
        <button
          onClick={openAdd}
          className="flex items-center gap-2 bg-sky-500 hover:bg-sky-400 text-white text-sm font-semibold px-4 py-2.5 rounded-xl transition"
        >
          <Plus className="w-4 h-4" /> Add Property
        </button>
      </div>

      {properties.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center">
          <Home className="w-10 h-10 text-slate-700 mx-auto mb-3" />
          <p className="text-slate-400 font-medium">No properties yet</p>
          <p className="text-slate-600 text-sm mt-1">Add your first property to get started</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {properties.map((p) => {
            const gain = p.current_value - p.purchase_price;
            const roi = p.purchase_price > 0 ? (gain / p.purchase_price) * 100 : 0;
            const positive = gain >= 0;
            return (
              <div key={p.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col gap-4 hover:border-slate-700 transition">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-white truncate">{p.name}</p>
                    <p className="text-slate-500 text-xs truncate mt-0.5">{p.address}</p>
                    <span className="inline-block mt-2 text-xs bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full capitalize">{p.property_type}</span>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => openEdit(p)} className="p-1.5 rounded-lg text-slate-500 hover:text-sky-400 hover:bg-sky-400/10 transition">
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => remove(p.id)} className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-400/10 transition">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-800/50 rounded-xl p-3">
                    <p className="text-xs text-slate-500 mb-1">Purchase Price</p>
                    <p className="text-sm font-semibold text-white">{fmt(p.purchase_price, currency)}</p>
                  </div>
                  <div className="bg-slate-800/50 rounded-xl p-3">
                    <p className="text-xs text-slate-500 mb-1">Current Value</p>
                    <p className="text-sm font-semibold text-white">{fmt(p.current_value, currency)}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                  <div className="flex items-center gap-1.5">
                    {positive ? (
                      <TrendingUp className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-400" />
                    )}
                    <span className={`text-sm font-semibold ${positive ? 'text-emerald-400' : 'text-red-400'}`}>
                      {positive ? '+' : ''}{fmt(gain, currency)}
                    </span>
                  </div>
                  <span className={`text-sm font-bold ${positive ? 'text-emerald-400' : 'text-red-400'}`}>
                    {roi >= 0 ? '+' : ''}{roi.toFixed(1)}% ROI
                  </span>
                </div>

                {p.purchase_date && (
                  <p className="text-xs text-slate-600">Purchased {p.purchase_date}</p>
                )}
              </div>
            );
          })}
        </div>
      )}

      {modal && (
        <Modal title={modal === 'add' ? 'Add Property' : 'Edit Property'} onClose={() => setModal(null)}>
          <div className="space-y-3">
            {field('name', 'Property Name')}
            {field('address', 'Address')}
            {field('property_type', 'Type', 'text', TYPES)}
            <div className="grid grid-cols-2 gap-3">
              {field('purchase_price', 'Purchase Price ($)', 'number')}
              {field('current_value', 'Current Value ($)', 'number')}
            </div>
            {field('purchase_date', 'Purchase Date', 'date')}
            {field('notes', 'Notes')}
            {error && <p className="text-red-400 text-xs">{error}</p>}
            <div className="flex gap-3 pt-2">
              <button onClick={() => setModal(null)} className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 text-sm hover:bg-slate-800 transition">Cancel</button>
              <button onClick={save} disabled={saving} className="flex-1 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-sm font-semibold transition disabled:opacity-50">
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
