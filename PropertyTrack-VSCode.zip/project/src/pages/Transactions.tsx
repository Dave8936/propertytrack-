import { useEffect, useState } from 'react';
import { Plus, ArrowLeftRight, Pencil, Trash2, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { supabase, Transaction, Property } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';
import Modal from '../components/Modal';

function fmt(n: number, currency: string) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 2 }).format(n);
}

const INCOME_CATS = ['rent', 'late fee', 'deposit', 'other income'];
const EXPENSE_CATS = ['mortgage', 'repairs', 'maintenance', 'insurance', 'tax', 'utilities', 'management fee', 'other expense'];

const emptyTx = (): Partial<Transaction> => ({
  property_id: '', type: 'income', category: 'rent',
  amount: 0, date: new Date().toISOString().split('T')[0], description: '',
});

export default function Transactions() {
  const { user } = useAuth();
  const { currency } = useCurrency();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<'add' | 'edit' | null>(null);
  const [form, setForm] = useState<Partial<Transaction>>(emptyTx());
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterProp, setFilterProp] = useState('all');

  async function load() {
    if (!user) return;
    const [tx, p] = await Promise.all([
      supabase.from('transactions').select('*').eq('user_id', user.id).order('date', { ascending: false }),
      supabase.from('properties').select('*').eq('user_id', user.id),
    ]);
    setTransactions(tx.data ?? []);
    setProperties(p.data ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, [user]);

  function openAdd() {
    setForm({ ...emptyTx(), property_id: properties[0]?.id ?? '' });
    setError('');
    setModal('add');
  }

  function openEdit(tx: Transaction) {
    setForm({ ...tx });
    setError('');
    setModal('edit');
  }

  async function save() {
    if (!user) return;
    setSaving(true);
    setError('');
    const payload = {
      user_id: user.id,
      property_id: form.property_id,
      type: form.type,
      category: form.category,
      amount: Number(form.amount),
      date: form.date,
      description: form.description ?? '',
    };
    let err;
    if (modal === 'add') {
      ({ error: err } = await supabase.from('transactions').insert(payload));
    } else {
      ({ error: err } = await supabase.from('transactions').update(payload).eq('id', (form as Transaction).id));
    }
    if (err) { setError(err.message); } else { setModal(null); await load(); }
    setSaving(false);
  }

  async function remove(id: string) {
    if (!confirm('Delete this transaction?')) return;
    await supabase.from('transactions').delete().eq('id', id);
    await load();
  }

  const cats = form.type === 'income' ? INCOME_CATS : EXPENSE_CATS;

  const visible = transactions.filter((t) => {
    if (filterType !== 'all' && t.type !== filterType) return false;
    if (filterProp !== 'all' && t.property_id !== filterProp) return false;
    return true;
  });

  const totalIncome = visible.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpense = visible.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Transactions</h1>
          <p className="text-slate-400 text-sm mt-1">{transactions.length} total records</p>
        </div>
        <button
          onClick={openAdd}
          disabled={properties.length === 0}
          title={properties.length === 0 ? 'Add a property first' : ''}
          className="flex items-center gap-2 bg-sky-500 hover:bg-sky-400 disabled:opacity-40 text-white text-sm font-semibold px-4 py-2.5 rounded-xl transition"
        >
          <Plus className="w-4 h-4" /> Add Transaction
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
          <p className="text-xs text-slate-500">Income</p>
          <p className="text-lg font-bold text-emerald-400 mt-1">{fmt(totalIncome, currency)}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
          <p className="text-xs text-slate-500">Expenses</p>
          <p className="text-lg font-bold text-red-400 mt-1">{fmt(totalExpense, currency)}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-center">
          <p className="text-xs text-slate-500">Net</p>
          <p className={`text-lg font-bold mt-1 ${totalIncome - totalExpense >= 0 ? 'text-white' : 'text-red-400'}`}>
            {fmt(totalIncome - totalExpense, currency)}
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <div className="flex gap-1">
          {(['all', 'income', 'expense'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilterType(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                filterType === f ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
        <select
          value={filterProp}
          onChange={(e) => setFilterProp(e.target.value)}
          className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-slate-400 text-xs focus:outline-none focus:border-sky-500 transition"
        >
          <option value="all">All Properties</option>
          {properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>

      {/* List */}
      {visible.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center">
          <ArrowLeftRight className="w-10 h-10 text-slate-700 mx-auto mb-3" />
          <p className="text-slate-400 font-medium">No transactions found</p>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl divide-y divide-slate-800 overflow-hidden">
          {visible.map((tx) => {
            const prop = properties.find((p) => p.id === tx.property_id);
            return (
              <div key={tx.id} className="flex items-center gap-4 px-5 py-4 hover:bg-slate-800/30 transition">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${
                  tx.type === 'income' ? 'bg-emerald-500/15' : 'bg-red-500/15'
                }`}>
                  {tx.type === 'income'
                    ? <ArrowUpRight className="w-4 h-4 text-emerald-400" />
                    : <ArrowDownRight className="w-4 h-4 text-red-400" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white font-medium">{tx.description || tx.category}</p>
                  <p className="text-xs text-slate-500">{prop?.name ?? 'Unknown'} · <span className="capitalize">{tx.category}</span> · {tx.date}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className={`text-sm font-semibold ${tx.type === 'income' ? 'text-emerald-400' : 'text-red-400'}`}>
                    {tx.type === 'income' ? '+' : '-'}{fmt(tx.amount, currency)}
                  </p>
                </div>
                <div className="flex gap-1 flex-shrink-0">
                  <button onClick={() => openEdit(tx)} className="p-1.5 rounded-lg text-slate-500 hover:text-sky-400 hover:bg-sky-400/10 transition">
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => remove(tx.id)} className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-400/10 transition">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modal && (
        <Modal title={modal === 'add' ? 'Add Transaction' : 'Edit Transaction'} onClose={() => setModal(null)}>
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Property</label>
              <select
                value={form.property_id ?? ''}
                onChange={(e) => setForm((f) => ({ ...f, property_id: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-sky-500 transition"
              >
                {properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5">Type</label>
                <select
                  value={form.type ?? 'income'}
                  onChange={(e) => setForm((f) => ({ ...f, type: e.target.value as 'income' | 'expense', category: e.target.value === 'income' ? INCOME_CATS[0] : EXPENSE_CATS[0] }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-sky-500 transition"
                >
                  <option value="income">Income</option>
                  <option value="expense">Expense</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5">Category</label>
                <select
                  value={form.category ?? cats[0]}
                  onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-sky-500 transition"
                >
                  {cats.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5">Amount ($)</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={form.amount ?? 0}
                  onChange={(e) => setForm((f) => ({ ...f, amount: Number(e.target.value) }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-sky-500 transition"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5">Date</label>
                <input
                  type="date"
                  value={form.date ?? ''}
                  onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-sky-500 transition"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1.5">Description</label>
              <input
                type="text"
                value={form.description ?? ''}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2.5 text-white text-sm focus:outline-none focus:border-sky-500 transition"
              />
            </div>
            {error && <p className="text-red-400 text-xs">{error}</p>}
            <div className="flex gap-3 pt-2">
              <button onClick={() => setModal(null)} className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 text-sm hover:bg-slate-800 transition">Cancel</button>
              <button onClick={save} disabled={saving} className="flex-1 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white text-sm font-semibold transition disabled:opacity-50">
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
