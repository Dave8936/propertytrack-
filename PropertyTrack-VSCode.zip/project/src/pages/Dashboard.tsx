import { useEffect, useState } from 'react';
import { TrendingUp, Home, Users, DollarSign, ArrowUpRight, ArrowDownRight, BarChart3 } from 'lucide-react';
import { supabase, Property, Transaction, Tenant } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { useCurrency } from '../context/CurrencyContext';

function fmt(n: number, currency: string) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(n);
}

function pct(n: number) {
  return `${n >= 0 ? '+' : ''}${n.toFixed(1)}%`;
}

type StatCardProps = {
  label: string;
  value: string;
  sub?: string;
  positive?: boolean;
  icon: typeof Home;
  color: string;
};

function StatCard({ label, value, sub, positive, icon: Icon, color }: StatCardProps) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="text-slate-400 text-sm">{label}</span>
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${color}`}>
          <Icon className="w-4 h-4 text-white" />
        </div>
      </div>
      <div>
        <p className="text-2xl font-bold text-white">{value}</p>
        {sub !== undefined && (
          <p className={`text-xs mt-1 flex items-center gap-1 ${positive ? 'text-emerald-400' : positive === false ? 'text-red-400' : 'text-slate-500'}`}>
            {positive === true && <ArrowUpRight className="w-3 h-3" />}
            {positive === false && <ArrowDownRight className="w-3 h-3" />}
            {sub}
          </p>
        )}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const { currency } = useCurrency();
  const [properties, setProperties] = useState<Property[]>([]);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      if (!user) return;
      const [p, t, tx] = await Promise.all([
        supabase.from('properties').select('*').eq('user_id', user.id),
        supabase.from('tenants').select('*').eq('user_id', user.id).eq('status', 'active'),
        supabase.from('transactions').select('*').eq('user_id', user.id),
      ]);
      setProperties(p.data ?? []);
      setTenants(t.data ?? []);
      setTransactions(tx.data ?? []);
      setLoading(false);
    }
    load();
  }, [user]);

  const totalPortfolioValue = properties.reduce((s, p) => s + p.current_value, 0);
  const totalInvested = properties.reduce((s, p) => s + p.purchase_price, 0);
  const appreciation = totalPortfolioValue - totalInvested;
  const appreciationPct = totalInvested > 0 ? (appreciation / totalInvested) * 100 : 0;

  const totalIncome = transactions.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpenses = transactions.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const netIncome = totalIncome - totalExpenses;

  const totalROI = totalInvested > 0
    ? ((netIncome + appreciation) / totalInvested) * 100
    : 0;

  // monthly income from active tenants
  const monthlyRent = tenants.reduce((s, t) => s + t.monthly_rent, 0);

  // last 6 months chart data
  const monthlyData = (() => {
    const now = new Date();
    return Array.from({ length: 6 }, (_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const inc = transactions
        .filter((t) => t.type === 'income' && t.date.startsWith(key))
        .reduce((s, t) => s + t.amount, 0);
      const exp = transactions
        .filter((t) => t.type === 'expense' && t.date.startsWith(key))
        .reduce((s, t) => s + t.amount, 0);
      return { label: d.toLocaleString('default', { month: 'short' }), income: inc, expense: exp };
    });
  })();

  const maxBar = Math.max(...monthlyData.map((m) => Math.max(m.income, m.expense)), 1);

  const recentTx = [...transactions]
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 5);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-slate-400 text-sm mt-1">Overview of your property portfolio</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          label="Portfolio Value"
          value={fmt(totalPortfolioValue, currency)}
          sub={`${pct(appreciationPct)} appreciation`}
          positive={appreciationPct >= 0}
          icon={Home}
          color="bg-sky-500"
        />
        <StatCard
          label="Total ROI"
          value={pct(totalROI)}
          sub={`Net income + appreciation`}
          positive={totalROI >= 0}
          icon={TrendingUp}
          color="bg-emerald-500"
        />
        <StatCard
          label="Monthly Rent"
          value={fmt(monthlyRent, currency)}
          sub={`${tenants.length} active tenant${tenants.length !== 1 ? 's' : ''}`}
          icon={Users}
          color="bg-amber-500"
        />
        <StatCard
          label="Net Income"
          value={fmt(netIncome, currency)}
          sub={`${fmt(totalIncome, currency)} in, ${fmt(totalExpenses, currency)} out`}
          positive={netIncome >= 0}
          icon={DollarSign}
          color={netIncome >= 0 ? 'bg-emerald-600' : 'bg-red-500'}
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Chart */}
        <div className="xl:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-semibold text-white text-sm">Income vs Expenses</h2>
              <p className="text-slate-500 text-xs">Last 6 months</p>
            </div>
            <BarChart3 className="w-4 h-4 text-slate-600" />
          </div>
          <div className="flex items-end gap-3 h-40">
            {monthlyData.map((m) => (
              <div key={m.label} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex items-end gap-0.5 h-32">
                  <div
                    className="flex-1 bg-sky-500 rounded-t-sm transition-all"
                    style={{ height: `${(m.income / maxBar) * 100}%` }}
                    title={`Income: ${fmt(m.income, currency)}`}
                  />
                  <div
                    className="flex-1 bg-red-400/70 rounded-t-sm transition-all"
                    style={{ height: `${(m.expense / maxBar) * 100}%` }}
                    title={`Expense: ${fmt(m.expense, currency)}`}
                  />
                </div>
                <span className="text-xs text-slate-500">{m.label}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center gap-4 mt-3 pt-3 border-t border-slate-800">
            <span className="flex items-center gap-1.5 text-xs text-slate-400">
              <span className="w-3 h-3 rounded-sm bg-sky-500 inline-block" /> Income
            </span>
            <span className="flex items-center gap-1.5 text-xs text-slate-400">
              <span className="w-3 h-3 rounded-sm bg-red-400/70 inline-block" /> Expenses
            </span>
          </div>
        </div>

        {/* Properties summary */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
          <h2 className="font-semibold text-white text-sm mb-4">Properties</h2>
          {properties.length === 0 ? (
            <p className="text-slate-500 text-sm">No properties yet.</p>
          ) : (
            <div className="space-y-3">
              {properties.map((p) => {
                const roi = p.purchase_price > 0
                  ? ((p.current_value - p.purchase_price) / p.purchase_price) * 100
                  : 0;
                return (
                  <div key={p.id} className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white font-medium truncate">{p.name}</p>
                      <p className="text-xs text-slate-500 truncate">{p.address}</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-sm text-white font-semibold">{fmt(p.current_value, currency)}</p>
                      <p className={`text-xs ${roi >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{pct(roi)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Recent transactions */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
        <h2 className="font-semibold text-white text-sm mb-4">Recent Transactions</h2>
        {recentTx.length === 0 ? (
          <p className="text-slate-500 text-sm">No transactions yet.</p>
        ) : (
          <div className="divide-y divide-slate-800">
            {recentTx.map((tx) => {
              const prop = properties.find((p) => p.id === tx.property_id);
              return (
                <div key={tx.id} className="flex items-center justify-between py-3 gap-4">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white">{tx.description || tx.category}</p>
                    <p className="text-xs text-slate-500">{prop?.name ?? 'Unknown'} · {tx.date}</p>
                  </div>
                  <span className={`text-sm font-semibold ${tx.type === 'income' ? 'text-emerald-400' : 'text-red-400'}`}>
                    {tx.type === 'income' ? '+' : '-'}{fmt(tx.amount, currency)}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
