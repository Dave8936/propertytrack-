import { ReactNode, useState } from 'react';
import {
  Building2, LayoutDashboard, Home, Users, ArrowLeftRight,
  LogOut, Menu, X, ChevronRight, Globe
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCurrency, CURRENCIES, Currency } from '../context/CurrencyContext';

type Page = 'dashboard' | 'properties' | 'tenants' | 'transactions';

type LayoutProps = {
  page: Page;
  onNavigate: (p: Page) => void;
  children: ReactNode;
};

const navItems: { id: Page; label: string; icon: typeof Home }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'properties', label: 'Properties', icon: Home },
  { id: 'tenants', label: 'Tenants', icon: Users },
  { id: 'transactions', label: 'Transactions', icon: ArrowLeftRight },
];

export default function Layout({ page, onNavigate, children }: LayoutProps) {
  const { user, signOut } = useAuth();
  const { currency, setCurrency } = useCurrency();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [currencyOpen, setCurrencyOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 flex">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-slate-900 border-r border-slate-800 flex flex-col
          transform transition-transform duration-200
          ${mobileOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}
      >
        <div className="flex items-center gap-3 px-5 h-16 border-b border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-sky-500 flex items-center justify-center flex-shrink-0">
            <Building2 className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-white text-lg">PropertyTrack</span>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => { onNavigate(id); setMobileOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group
                ${page === id
                  ? 'bg-sky-500/15 text-sky-400'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
            >
              <Icon className="w-4 h-4" />
              {label}
              {page === id && <ChevronRight className="w-3 h-3 ml-auto" />}
            </button>
          ))}
        </nav>

        <div className="px-3 py-4 border-t border-slate-800">
          <div className="px-3 py-2 mb-2">
            <p className="text-xs text-slate-500 truncate">{user?.email}</p>
          </div>
          <button
            onClick={signOut}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:bg-red-500/10 hover:text-red-400 transition-all"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/60 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Main */}
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        {/* Top bar desktop */}
        <header className="h-14 border-b border-slate-800 hidden lg:flex items-center justify-between px-8 bg-slate-900">
          <div />
          <div className="relative">
            <button
              onClick={() => setCurrencyOpen(!currencyOpen)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-400/10 transition text-sm font-medium"
            >
              <Globe className="w-4 h-4" />
              {currency}
            </button>
            {currencyOpen && (
              <div className="absolute right-0 mt-1 w-48 bg-slate-800 border border-slate-700 rounded-lg shadow-lg z-50">
                {(Object.keys(CURRENCIES) as Currency[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => { setCurrency(c); setCurrencyOpen(false); }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-700 transition ${
                      currency === c ? 'bg-sky-500/20 text-sky-400' : 'text-slate-300'
                    }`}
                  >
                    <span>{c} - {CURRENCIES[c].name}</span>
                    {currency === c && <span className="text-sky-400">✓</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        </header>

        {/* Top bar mobile */}
        <header className="h-16 border-b border-slate-800 flex items-center justify-between px-4 lg:hidden bg-slate-900">
          <div className="flex items-center">
            <button onClick={() => setMobileOpen(true)} className="text-slate-400 hover:text-white">
              <Menu className="w-5 h-5" />
            </button>
            <span className="ml-3 font-semibold text-white">
              {navItems.find((n) => n.id === page)?.label}
            </span>
          </div>
          <div className="relative">
            <button
              onClick={() => setCurrencyOpen(!currencyOpen)}
              className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-400/10 transition text-sm"
            >
              <Globe className="w-4 h-4" />
              {currency}
            </button>
            {currencyOpen && (
              <div className="absolute right-0 mt-1 w-40 bg-slate-800 border border-slate-700 rounded-lg shadow-lg z-50">
                {(Object.keys(CURRENCIES) as Currency[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => { setCurrency(c); setCurrencyOpen(false); }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-700 transition ${
                      currency === c ? 'bg-sky-500/20 text-sky-400' : 'text-slate-300'
                    }`}
                  >
                    <span>{c} - {CURRENCIES[c].name}</span>
                    {currency === c && <span className="text-sky-400">✓</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
          {mobileOpen && (
            <button onClick={() => setMobileOpen(false)} className="text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          )}
        </header>

        <main className="flex-1 p-4 lg:p-8 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
