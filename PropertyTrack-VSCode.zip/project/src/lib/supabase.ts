import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Property = {
  id: string;
  user_id: string;
  name: string;
  address: string;
  property_type: string;
  purchase_price: number;
  current_value: number;
  purchase_date: string | null;
  notes: string;
  created_at: string;
};

export type Tenant = {
  id: string;
  user_id: string;
  property_id: string;
  name: string;
  email: string;
  phone: string;
  monthly_rent: number;
  lease_start: string | null;
  lease_end: string | null;
  status: string;
  notes: string;
  created_at: string;
};

export type Transaction = {
  id: string;
  user_id: string;
  property_id: string;
  type: 'income' | 'expense';
  category: string;
  amount: number;
  date: string;
  description: string;
  created_at: string;
};
