# PropertyTrack

A property management app built with React, TypeScript, Tailwind CSS, Vite, and Supabase.

## Prerequisites

- [Node.js](https://nodejs.org/) v18 or higher
- [VS Code](https://code.visualstudio.com/)
- A [Supabase](https://supabase.com) account (free tier works)

## Getting Started in VS Code

### 1. Open the project
Open this folder in VS Code: **File → Open Folder** → select this folder.

VS Code will prompt you to install recommended extensions — click **Install All**.

### 2. Install dependencies
Open the integrated terminal (`Ctrl+`` ` ``) and run:
```bash
npm install
```

### 3. Set up environment variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Then edit `.env` and fill in your Supabase URL and anon key.

> **Where to find these:** Supabase Dashboard → your project → Settings → API

### 4. Set up the database
In your Supabase project, go to **SQL Editor** and run the migration file:
```
supabase/migrations/20260429191347_create_property_tracker_schema.sql
```

### 5. Run the dev server
Press `Ctrl+Shift+B` to run the default build task (starts the dev server), or run:
```bash
npm run dev
```
Then open [http://localhost:5173](http://localhost:5173) in your browser.

## VS Code Tasks (Ctrl+Shift+B)

| Task | Description |
|------|-------------|
| **Dev Server** *(default)* | Start the Vite dev server |
| **Build** | Build for production → `dist/` |
| **Install Dependencies** | Run `npm install` |
| **Type Check** | Run TypeScript compiler check |

## Project Structure

```
src/
  App.tsx                   # Routes & app entry
  main.tsx                  # React root
  index.css                 # Global Tailwind styles
  components/
    Layout.tsx              # Sidebar + navbar with currency selector
    Modal.tsx               # Reusable modal
  context/
    AuthContext.tsx          # Supabase auth state
    CurrencyContext.tsx      # Global currency (8 currencies)
  lib/
    supabase.ts             # Supabase client + TypeScript types
  pages/
    AuthPage.tsx            # Login / sign-up
    Dashboard.tsx           # Portfolio overview & charts
    Properties.tsx          # Property CRUD
    Tenants.tsx             # Tenant management
    Transactions.tsx        # Income / expense log
supabase/
  migrations/               # SQL schema
.vscode/
  settings.json             # Editor settings
  extensions.json           # Recommended extensions
  launch.json               # Debug configuration
  tasks.json                # Build tasks
```

## Tech Stack

- **React 18** + **TypeScript**
- **Tailwind CSS** for styling
- **Vite** for dev server & bundling
- **Supabase** for database, auth, and API
- **Lucide React** for icons

## Build for Production

```bash
npm run build
```
Output goes to `dist/`. Deploy to Netlify, Vercel, or any static host.
